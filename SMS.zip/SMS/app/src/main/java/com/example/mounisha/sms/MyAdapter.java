package com.example.mounisha.sms;

import android.content.Context;
import android.content.Intent;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MyAdapter  extends RecyclerView.Adapter<MyAdapter.MyViewHolder> implements Filterable{
    Context c;
    List<Cardfill> l;
    List<Cardfill> contactListFiltered;

    public MyAdapter(Context c, List<Cardfill> l)
    {
        this.c = c;
        this.l = l;
    }
    public void removeItem(int position) {
        l.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, l.size());
    }
    public void restoreItem(Cardfill model, int position) {
        l.add(position, model);
        // notify item added by position
        notifyItemInserted(position);
    }
    @Override
    public MyViewHolder onCreateViewHolder( ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row,parent,false);
        return new MyViewHolder(view);
    }


    @Override
    public void onBindViewHolder( MyViewHolder holder,  int position) {
        final Cardfill current=l.get(position);
        holder.myimage.setImageResource(current.getImageresource());
        holder.contact.setText(current.getT1());
        holder.message.setText(current.getT2());

        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(c,MessageView.class);
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                i.putExtra("image_url",current.getImageresource());
                i.putExtra("Name_of_contact",current.getT1());
                i.putExtra("message",current.getT2());
                i.putExtra("id",current.getID_c());
                c.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return l.size();
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence charSequence) {
                String charString = charSequence.toString();
                if (charString.isEmpty()) {
                    contactListFiltered =l;
                } else {
                    List<Cardfill> filteredList = new ArrayList<>();
                    for (Cardfill row : l) {

                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (row.getT1().toLowerCase().contains(charString.toLowerCase())) {
                            filteredList.add(row);
                        }
                    }

                    contactListFiltered = filteredList;
                }

                FilterResults filterResults = new FilterResults();
                filterResults.values = contactListFiltered;
                return filterResults;
            }
            @Override
            protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                contactListFiltered = (ArrayList<Cardfill>) filterResults.values;
                notifyDataSetChanged();
            }
        };
    }

    public String getContact(int position) {
        String contact="";
        final Cardfill current=l.get(position);
        return current.getT1();
    }

    class MyViewHolder extends RecyclerView.ViewHolder{
        ImageView myimage;
        TextView contact,message,id;
        CardView cardView;
        public MyViewHolder(final View itemView) {
            super(itemView);
            myimage =itemView.findViewById(R.id.imageview);
            contact= itemView.findViewById(R.id.t1);
            message=itemView.findViewById(R.id.t2);
            id=itemView.findViewById(R.id.id_id);
            cardView =itemView.findViewById(R.id.singleitem);
        }
    }
}
