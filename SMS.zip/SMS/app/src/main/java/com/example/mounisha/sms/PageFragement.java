package com.example.mounisha.sms;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.RadioButton;
import android.widget.TextView;

public class PageFragement extends AppCompatActivity {
    RadioButton aes,rsa,idea;
    TextView about_algorithms;
    Intent i1,i;
    private static String num=" ";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_fragement);
        aes=findViewById(R.id.AES);
        rsa=findViewById(R.id.RSA);
        idea=findViewById(R.id.IDEA);
        i=new Intent(PageFragement.this,NewMessage.class);
        i1=getIntent();
        num=i1.getStringExtra("sendnumber");
        about_algorithms=findViewById(R.id.tell_about_alg);
        aes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "AES is selected", Toast.LENGTH_SHORT).show();
                about_algorithms.setText("Selected Algorithm is AES\nTime for Security : 1-2 years");

            }
        });
        rsa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "RSA is selected", Toast.LENGTH_SHORT).show();
                about_algorithms.setText("Selected Algorithm is RSA\nTime for Security : 3-9 months");


            }
        });
        idea.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Toast.makeText(getApplicationContext(), "IDEA is selected", Toast.LENGTH_SHORT).show();
                about_algorithms.setText("Selected Algorithm is IDEA\nTime for Security : 1-3 Years");

            }
        });
    }

    public void Next(View view) {
        if(aes.isChecked())
            i.putExtra("algorithm",aes.getText().toString());
        if(rsa.isChecked())
            i.putExtra("algorithm",rsa.getText().toString());
        if(idea.isChecked())
            i.putExtra("algorithm",idea.getText().toString());
        startActivity(i);
    }

    public static String getNum() {
        return num;
    }
}
