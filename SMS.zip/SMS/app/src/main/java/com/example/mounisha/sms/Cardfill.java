package com.example.mounisha.sms;

public class Cardfill {
    public int imageresource;
    public String receivernumber,message_entered,ID_c;
    public Cardfill( int imageresource,String receivernumber,String message_entered,String ID_c)
    {
        this.imageresource = R.drawable.ic_person_black_24dp;
        this.receivernumber = receivernumber;
        this.message_entered = message_entered;
        this.ID_c=ID_c;

    }
    public Cardfill()
    {

    }

    public String getID_c() {
        return ID_c;
    }

    public void setID_c(String ID) {
        ID_c = ID;
    }

    public int getImageresource() {
        return imageresource;
    }

    public String getT1() {
        return receivernumber;
    }

    public String getT2() {
        return message_entered;
    }
}
