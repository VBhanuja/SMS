package com.example.mounisha.sms;

public class NotifyFill {
    String Contact_name,notification_body;
    public NotifyFill(String Contact_name,String notification_body)
    {
        this.Contact_name = Contact_name;
        this.notification_body = notification_body;
    }

    public String getContact_name() {
        return Contact_name;
    }

    public String getNotification_body() {
        return notification_body;
    }

    public void setContact_name(String contact_name) {
        Contact_name = contact_name;
    }

    public void setNotification_body(String notification_body) {
        this.notification_body = notification_body;
    }
}
