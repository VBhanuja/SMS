package com.example.mounisha.sms;

public class StoringData {
    private String sendernumber;
    private String secretkey;
    private String receivernumber;
    private String message_entered;
    private String algorithm;
    private String privatekey;
    private String publickey;
    private String time_of_sent;
    private String ID;


    public StoringData(String ID, String sendernumber, String receivernumber, String message_entered, String algorithm, String time_of_sent)
   {
       this.ID=ID;
       this.sendernumber = sendernumber;
       this.receivernumber = receivernumber;
       this.message_entered = message_entered;
       this.algorithm = algorithm;
       this.time_of_sent = time_of_sent;
   }
    public StoringData()
    {
        this.receivernumber = receivernumber;
        this.message_entered = message_entered;
        this.algorithm = algorithm;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public String getMessage_entered() {
        return message_entered;
    }

    public String getReceivernumber() {
        return receivernumber;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public void setReceivernumber(String receivernumber) {
        this.receivernumber = receivernumber;
    }

    public void setMessage_entered(String message_entered) {
        this.message_entered = message_entered;
    }

    public String getSecretkey() {
        return secretkey;
    }

    public String getPrivatekey() {
        return privatekey;
    }

    public String getPublickey() {
        return publickey;
    }

    public void setPrivatekey(String privatekey) {
        this.privatekey = privatekey;
    }

    public void setSecretkey(String secretkey) {
        this.secretkey = secretkey;
    }

    public void setPublickey(String publickey) {
        this.publickey = publickey;
    }

    public String getSendernumber() {
        return sendernumber;
    }

    public void setSendernumber(String sendernumber) {
        this.sendernumber = sendernumber;
    }

    public String getTime_of_sent() {
        return time_of_sent;
    }

    public void setTime_of_sent(String time_of_sent) {
        this.time_of_sent = time_of_sent;
    }
}
