package com.example.mounisha.sms;
import android.util.Base64;

import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.Cipher;

public class Rsa {
   public static final String KEY_ALGORITHM="RSA";
    public static final String SIGNATURE_ALGORITHM="MD5withRSA";
    private static final String PUBLIC_KEY="RSAPublicKey";
    private static final String PRIVATE_KEY="RSAPrivateKey";
    public static byte[] decryptBASE64(String key) throws Exception{
        return Base64.decode(key, Base64.DEFAULT);
    }
    public static String encryptBASE64(byte[] key)throws Exception{
        return Base64.encodeToString(key,Base64.DEFAULT);
    }
    public static String sign(byte[] data,String privatekey)throws Exception{
        byte[] keyBytes=decryptBASE64(privatekey);
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec=new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);
        PrivateKey priKey=keyFactory.generatePrivate(pkcs8EncodedKeySpec);
        Signature signature=Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initSign(priKey);
        signature.update(data);
        return encryptBASE64(signature.sign());

    }
    public static boolean verify(byte[] data,String publicKey,String sign)throws Exception{
        byte[] keyBytes=decryptBASE64(publicKey);
        X509EncodedKeySpec keySpec=new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory= KeyFactory.getInstance(KEY_ALGORITHM);
        PublicKey pubkey=keyFactory.generatePublic(keySpec);
        Signature signature=Signature.getInstance(SIGNATURE_ALGORITHM);
        signature.initVerify(pubkey);
        signature.update(data);
        return signature.verify(decryptBASE64(sign));
    }
    public static byte[] decryptByPrivateKey(byte[] data,String key)throws Exception{
        byte[] keyBytes=decryptBASE64(key);
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec=new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);
        Key privateKey=keyFactory.generatePrivate(pkcs8EncodedKeySpec);
        Cipher cipher=Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.DECRYPT_MODE,privateKey);
        return cipher.doFinal(data);

    }
    public static byte[] encryptByPublicKey(byte[] data,String key)throws Exception{
        byte[] keyBytes=decryptBASE64(key);
        X509EncodedKeySpec x509EncodedKeySpec=new X509EncodedKeySpec(keyBytes);
        KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);
        Key publicKey=keyFactory.generatePublic(x509EncodedKeySpec);
        Cipher cipher=Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE,publicKey);
        return cipher.doFinal(data);
    }
    public static byte[] encryptByPrivateKey(byte[] data,String key)throws Exception
    {
        byte[] keyBytes=decryptBASE64(key);
        PKCS8EncodedKeySpec pkcs8EncodedKeySpec=new PKCS8EncodedKeySpec(keyBytes);
        KeyFactory keyFactory=KeyFactory.getInstance(KEY_ALGORITHM);
        Key privateKey=keyFactory.generatePrivate(pkcs8EncodedKeySpec);
        Cipher cipher=Cipher.getInstance(keyFactory.getAlgorithm());
        cipher.init(Cipher.ENCRYPT_MODE,privateKey);
        return cipher.doFinal(data);
    }
    public static String getPrivateKey(Map<String, Object> keyMap)throws Exception
    {
        Key key=(Key)keyMap.get(PRIVATE_KEY);
        return encryptBASE64(key.getEncoded());
    }
    public static String getPublicKey(Map<String, Object> keyMap)throws Exception{
        Key key=(Key)keyMap.get(PUBLIC_KEY);
        return encryptBASE64(key.getEncoded());
    }
    public static Map<String, Object> initKey()throws Exception{
        KeyPairGenerator keyPairGenerator=KeyPairGenerator.getInstance(KEY_ALGORITHM);
        keyPairGenerator.initialize(1024);
        KeyPair keyPair=keyPairGenerator.generateKeyPair();
        RSAPublicKey publicKey=(RSAPublicKey)keyPair.getPublic();
        RSAPrivateKey privateKey=(RSAPrivateKey)keyPair.getPrivate();
        Map<String, Object> keyMap=new HashMap<String, Object>(2);
        keyMap.put(PUBLIC_KEY,publicKey);
        keyMap.put(PRIVATE_KEY,privateKey);
        return keyMap;
    }

/*  private BigInteger p;
    private BigInteger q;
    private static BigInteger N;
    private BigInteger phi;
    private static BigInteger e;
    private BigInteger d;
    private int        bitlength = 1024;
    private Random     r;

    public void getkeys()
    {
        r = new Random();
        p = BigInteger.probablePrime(bitlength, r);
        q = BigInteger.probablePrime(bitlength, r);
        N = p.multiply(q);
        phi = p.subtract(BigInteger.ONE).multiply(q.subtract(BigInteger.ONE));
        e = BigInteger.probablePrime(bitlength / 2, r);
        while (phi.gcd(e).compareTo(BigInteger.ONE) > 0 && e.compareTo(phi) < 0)
        {
            e.add(BigInteger.ONE);
        }
        d = e.modInverse(phi);
    }

    public Rsa(BigInteger e, BigInteger d, BigInteger N)
    {
        this.e = e;
        this.d = d;
        this.N = N;
    }

   /* @SuppressWarnings("deprecation")
    public static void main(String[] args) throws IOException
    {
        RSA rsa = new RSA();
        DataInputStream in = new DataInputStream(System.in);
        String teststring;
        System.out.println("Enter the plain text:");
        teststring = in.readLine();
        System.out.println("Encrypting String: " + teststring);
        System.out.println("String in Bytes: "
                + bytesToString(teststring.getBytes()));
        // encrypt
        byte[] encrypted = rsa.encrypt(teststring.getBytes());
        // decrypt
        byte[] decrypted = rsa.decrypt(encrypted);
        System.out.println("Decrypting Bytes: " + bytesToString(decrypted));
        System.out.println("Decrypted String: " + new String(decrypted));
    }

    private static String bytesToString(byte[] encrypted)
    {
        String test = "";
        for (byte b : encrypted)
        {
            test += Byte.toString(b);
        }
        return test;
    }

    // Encrypt message
    public static byte[] encrypt(byte[] message)
    {
        return (new BigInteger(message)).modPow(e, N).toByteArray();
    }

    // Decrypt message
    public byte[] decrypt(byte[] message)
    {
        return (new BigInteger(message)).modPow(d, N).toByteArray();
    }*/
}
