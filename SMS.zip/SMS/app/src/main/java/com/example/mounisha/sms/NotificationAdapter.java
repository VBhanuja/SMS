package com.example.mounisha.sms;

import android.content.Context;
import android.content.Intent;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class NotificationAdapter extends RecyclerView.Adapter<NotificationAdapter.MyNotificationViewHolder>{


    Context c;
    List<NotifyFill> l;

    public NotificationAdapter(Context c, List<NotifyFill> l)
    {
        this.c = c;
        this.l = l;
    }
    public void removeItem(int position) {
        l.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, l.size());
    }
    public void restoreItem(NotifyFill model, int position) {
        l.add(position, model);
        // notify item added by position
        notifyItemInserted(position);
    }
    @Override
    public MyNotificationViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.rown,parent,false);
        return new MyNotificationViewHolder(view);
    }
    @Override
    public void onBindViewHolder( MyNotificationViewHolder holder,  int position) {
        final NotifyFill current=l.get(position);
        holder.contact.setText(current.getContact_name());
        holder.message.setText(current.getNotification_body());
        holder.cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(c,NotificationView.class);
                i.putExtra("Name_of_contact",current.getContact_name());
                i.putExtra("message",current.getNotification_body());
                i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                c.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return l.size();
    }
    class MyNotificationViewHolder extends RecyclerView.ViewHolder{
        ImageView myimage;
        TextView contact,message;
        CardView cardView;
        public MyNotificationViewHolder(final View itemView) {
            super(itemView);
            contact= itemView.findViewById(R.id.id_notify_contact_name);
            message=itemView.findViewById(R.id.id_notify_contact_message);
            cardView =itemView.findViewById(R.id.id_notify_single_item);
        }
    }
}
