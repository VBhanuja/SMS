package com.example.mounisha.sms;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.ArrayAdapter;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Notification_try extends AppCompatActivity {
    private RecyclerView recyclerView;
    NotificationAdapter adapter;
    ArrayAdapter<NotifyFill> adapter1;
    private RecyclerView.LayoutManager layoutManager;
    List<NotifyFill> messagelist;
    DatabaseReference ref1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_try);
        recyclerView = findViewById(R.id.id_notification_recyclerview);
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        messagelist = new ArrayList<>();
        ref1 = FirebaseDatabase.getInstance().getReference(MainActivity.getNum()).child("Notification");
        loadNotifications();
        adapter = new NotificationAdapter(getApplicationContext(), messagelist);
        recyclerView.setAdapter(adapter);
    }

    private void loadNotifications() {
        ref1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                try {
                    for (DataSnapshot postsnapShot : dataSnapshot.getChildren()) {
                        NotifyStore map = postsnapShot.getValue(NotifyStore.class);
                        if (map != null) {
                            messagelist.add(new NotifyFill(map.getContact_name(), map.getNotification_body()));
                        }
                    }
                } catch (NullPointerException e) {
                }
                adapter = new NotificationAdapter(getApplicationContext(), messagelist);
                recyclerView.setAdapter(adapter);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("The read failed: " + databaseError.getCode());
            }
        });

    }
}
