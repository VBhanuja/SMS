package com.example.mounisha.sms;

public class NotifyStore {
    private String Contact_name,notification_body,acceptance;
    public NotifyStore(String Contact_name,String notification_body,String acceptance)
    {
        this.Contact_name = Contact_name;
        this.notification_body = notification_body;
        this.acceptance = acceptance;
    }
    public NotifyStore()
    {
    }


    public String getContact_name() {
        return Contact_name;
    }

    public String getNotification_body() {
        return notification_body;
    }

    public void setContact_name(String contact_name) {
        Contact_name = contact_name;
    }

    public void setNotification_body(String notification_body) {
        this.notification_body = notification_body;
    }

    public void setAcceptance(String acceptance) {
        this.acceptance = acceptance;
    }

    public String getAcceptance() {
        return acceptance;
    }

}
