package com.example.mounisha.sms;

import android.content.Intent;
import android.os.Bundle;
import com.google.android.material.snackbar.Snackbar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class NewMessage extends AppCompatActivity {
    EditText receipient, beforeencrptmessage;
    TextView secretkey, encryptmessage, changename;
    Intent intent;
    String algorithm;
    CardView secretcard;
    String number,encrytmess;
    String publicKey = "",privateKey="";
    DatabaseReference ref1;
    String sectk,acc;
    StoringData s;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_message);
        intent = getIntent();
        receipient = findViewById(R.id.recepient);
        secretcard = findViewById(R.id.secretcard);
        secretkey = findViewById(R.id.secretkey);
        changename = findViewById(R.id.changethename);
        beforeencrptmessage = findViewById(R.id.messagebeforeencryption);
        encryptmessage = findViewById(R.id.encrypted_message);
        algorithm = intent.getStringExtra("algorithm");
        number = PageFragement.getNum();
        ref1 = FirebaseDatabase.getInstance().getReference();
        getnecessaryKeys();
    }
    private String getPublicKey() {
        if (receiveReply().equals("true")) {
         String receipie = receipient.getText().toString();
            ref1 = FirebaseDatabase.getInstance().getReference(receipie);
            ref1.child("publickey").addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        try {
                            publicKey = dataSnapshot.getValue().toString();
                            //Toast.makeText(NewMessage.this, publicKey, Toast.LENGTH_SHORT).show();
                            secretkey.setText(publicKey);
                        } catch (NullPointerException e) {

                        }
                    }
                }
                @Override
                public void onCancelled(DatabaseError databaseError) {
                }
            });
        }
        return publicKey;
    }
    private String receiveReply() {
        ref1.child(receipient.getText().toString()).child("Notification").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                NotifyStore c=dataSnapshot.getValue(NotifyStore.class);
                try{
                acc= c.getAcceptance();}
                catch (NullPointerException e){}
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
        return acc;
    }
    private void sendNotification() {
        ref1.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                NotifyStore c=new NotifyStore(number,"your public key is being requested by this number show your acceptane/rejectance","");
                ref1.child("Notification").child(number).setValue(c, new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                        if(databaseError!=null)
                        {
                            Toast.makeText(NewMessage.this, "Notification is not sent", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(NewMessage.this, "Notification is sent", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
        getPublicKey();
    }
    private void getnecessaryKeys() {
        if (algorithm.equals("AES")) {
            secretcard.setVisibility(View.VISIBLE);
            sectk = AES3.generateSymmetricKey();
            secretkey.setText(sectk);
            setsecretkey();
        }
        if (algorithm.equals("RSA")) {

            secretcard.setVisibility(View.VISIBLE);
            changename.setText("Public key");
        }
    }
    private void setsecretkey() {
        final Map<String, Object> a = new HashMap<String, Object>();
        a.put("secretkey", sectk);
        ref1 = FirebaseDatabase.getInstance().getReference(number);
        ref1.child("secretkey").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    String s = dataSnapshot.getValue().toString();
                    if (s.equals("")) {
                        ref1.updateChildren(a);
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
    public void encrypt(View view) {
        if (algorithm.equals("RSA")) {
            byte[] rsaData = beforeencrptmessage.getText().toString().getBytes();
            if (rsaData.length != 0) {
                try {
                    encrytmess = RSA1.Encrypt(beforeencrptmessage.getText().toString());
                    encryptmessage.setText(encrytmess);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } else {
                Snackbar mySnackbar = Snackbar.make(findViewById(R.id.newmessagelayout),
                        "Enter the message", Snackbar.LENGTH_SHORT);
                mySnackbar.show();
            }
        }
        if (algorithm.equals("AES")) {
            encrytmess = AES4.encrypt(beforeencrptmessage.getText().toString(), sectk) ;
            encryptmessage.setText(encrytmess);
        }
    }
    public void sendSms(View view) {
        final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
        SimpleDateFormat dateFormat=new SimpleDateFormat("yyyy.MMMMM.dd GGG hh:mm aaa", Locale.getDefault());
        final String time=dateFormat.format(Calendar.getInstance().getTime());
        final String id=ref.child(receipient.getText().toString()).child("sms").push().getKey();
        ref.child(receipient.getText().toString()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                s = new StoringData(id,number, receipient.getText().toString(), encrytmess, algorithm,time);
                ref.child(s.getReceivernumber()).child("sms").child(id).setValue(s, new DatabaseReference.CompletionListener() {
                    @Override
                    public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                        if(databaseError!=null)
                        {
                            Toast.makeText(NewMessage.this, "SMS couldn't be  sent", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(NewMessage.this, "SMS is sent", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

    }
    private void reset() {
        secretkey.setText("");
        encryptmessage.setText("");
        beforeencrptmessage.setText("");
    }
    public void addReceipients(View view) {
    }
    public void sendNotification(View view) {
        sendNotification();
    }
}
