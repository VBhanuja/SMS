package com.example.mounisha.sms;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

public class NotificationView extends AppCompatActivity {
    String contact;
    String notification_message;
    TextView con,nom;
    DatabaseReference ref1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_view);
        Intent i=getIntent();
        contact=i.getStringExtra("Name_of_contact");
        notification_message=i.getStringExtra("message");
        con=findViewById(R.id.id_notify_contact_name_view);
        nom=findViewById(R.id.id_notify_contact_message_view);
        ref1=FirebaseDatabase.getInstance().getReference(MainActivity.getNum()).child("Notification").child(contact);
        con.setText(contact);
        nom.setText(notification_message);
    }
    public void setnotificationreplytoyes(View view) {
        final Map<String, Object> a = new HashMap<String, Object>();
        a.put("acceptance", "true");
        ref1.child("acceptance").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        String s = dataSnapshot.getValue().toString();
                        Toast.makeText(NotificationView.this, s, Toast.LENGTH_SHORT).show();
                        if (s.equals("")) {
                            ref1.updateChildren(a, new DatabaseReference.CompletionListener() {
                                @Override
                                public void onComplete(DatabaseError databaseError, DatabaseReference databaseReference) {
                                    if(databaseError!=null) {
                                        Toast.makeText(NotificationView.this, "Your reply is not updated", Toast.LENGTH_SHORT).show();
                                    }
                                    else
                                    {
                                        Toast.makeText(NotificationView.this, "Your reply is updated", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                        }
                    }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    public void setnotificationreplytoNo(View view) {
        final Map<String, Object> a = new HashMap<String, Object>();
        a.put("acceptance", "false");
        ref1.child("acceptance").addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    ref1.updateChildren(a);

                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }
}
