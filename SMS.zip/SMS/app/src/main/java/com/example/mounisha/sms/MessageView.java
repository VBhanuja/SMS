package com.example.mounisha.sms;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MessageView extends AppCompatActivity {
    TextView enncryptedmessagedisplay, algorithm_used_by, time_of_message, decryptedmessage, keys;
    DatabaseReference reference;
    String algorithm = "", secretq, secreta, number, Contact, encrypt_mess,time_of_mess,IDP;
    EditText sectqu, sectans;
    CardView l;
    String secretkey;
    String privatekey;
    static byte[] raw;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message_view);
        Intent i = getIntent();
        Contact = i.getStringExtra("Name_of_contact");
        encrypt_mess = i.getStringExtra("message");
        number = MainActivity.getNum();
        IDP=i.getStringExtra("id");
        l = findViewById(R.id.secretlayout);
        enncryptedmessagedisplay = findViewById(R.id.encrypted_message_retrived);
        algorithm_used_by = findViewById(R.id.algorithm_used);
        time_of_message = findViewById(R.id.timeof_message);
        decryptedmessage = findViewById(R.id.encrypted_message_retrived_decrypted);
        keys = findViewById(R.id.setting_keys);
        sectqu = findViewById(R.id.securityquestion_get);
        sectans = findViewById(R.id.securityanswer_get);
        reference = FirebaseDatabase.getInstance().getReference(number).child("sms").child(IDP);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    StoringData s = dataSnapshot.getValue(StoringData.class);
                    algorithm_used_by.setText(s.getAlgorithm());
                    algorithm = s.getAlgorithm();
                    time_of_mess=s.getTime_of_sent();
                    Toast.makeText(MessageView.this, time_of_mess, Toast.LENGTH_SHORT).show();
                    time_of_message.setText(time_of_mess);
                    enncryptedmessagedisplay.setText(encrypt_mess);
                    if (algorithm.equals("RSA")) {
                        setvisibily();
                    }
                    if (algorithm.equals("AES")) {
                        getkeys();
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
        //time_of_message.setText(time_of_mess);
        //enncryptedmessagedisplay.setText(encrypt_mess);
    }

    private void setvisibily() {
        l.setVisibility(View.VISIBLE);
        reference = FirebaseDatabase.getInstance().getReference(number);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    try {
                        secretq = dataSnapshot.child("securityquestion").getValue().toString();
                        privatekey = dataSnapshot.child("privatekey").getValue().toString();
                        secreta = dataSnapshot.child("securityanswer").getValue().toString();
                    } catch (NullPointerException e) {
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }

    private void getkeys() {
        reference = FirebaseDatabase.getInstance().getReference(Contact);
        reference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    try {
                        secretkey = dataSnapshot.child("secretkey").getValue().toString();
                    } catch (NullPointerException e) {
                    }
                }
            }
            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });
    }


    public void decrypt(View view) {
        if (algorithm.equals("RSA")) {
            byte[] input = encrypt_mess.getBytes();
            try {
               String decodeStr =RSA1.Decrypt(encrypt_mess);
                decryptedmessage.setText(decodeStr);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (algorithm.equals("AES")) {

            String decryptedString = AES4.decrypt(encrypt_mess, secretkey) ;
            decryptedmessage.setText(decryptedString);
        }
    }

    public void filtheprivatekey(View view) {
        if (algorithm.equals( "RSA")) {
            if ((secretq.equalsIgnoreCase(sectqu.getText().toString())) && ((secreta.equalsIgnoreCase(sectans.getText().toString())))) {
                keys.setText(privatekey);
            }
            else
            {
                Toast.makeText(this, "Please check your Security question and answer", Toast.LENGTH_SHORT).show();
            }
        }
        if (algorithm.equals("AES")) {
            keys.setText(secretkey);
        }
    }
}
