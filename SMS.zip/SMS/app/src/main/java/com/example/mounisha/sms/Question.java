package com.example.mounisha.sms;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class Question extends AppCompatActivity {
    EditText secques, secans;
    String phonenumber;
    AlertDialog alertDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
        secques = findViewById(R.id.securityquestion);
        secans = findViewById(R.id.securityanswer);
        Intent i = getIntent();
        phonenumber = i.getStringExtra("number");
    }

    public void addtodatabase(View view) {
        DatabaseReference ref = FirebaseDatabase.getInstance().getReference(phonenumber);
        ref.child("securityquestion").setValue(secques.getText().toString());
        ref.child("securityanswer").setValue(secans.getText().toString());
        Intent i = new Intent(Question.this, MainActivity.class);
        i.putExtra("number", phonenumber);
        startActivity(i);
        finish();
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setMessage("Are you sure,You don't want to fill it");
        alertDialogBuilder.setPositiveButton("I want to",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface arg0, int arg1) {
                    }
                });

        alertDialogBuilder.setNegativeButton("No I don't", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(Question.this, "Then you have to type you're private key", Toast.LENGTH_LONG).show();
                finish();
            }
        });
        final AlertDialog alertDialog= alertDialogBuilder.create();
        alertDialog.show();
    }
}

