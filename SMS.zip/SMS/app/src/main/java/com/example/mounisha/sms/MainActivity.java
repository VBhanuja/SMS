package com.example.mounisha.sms;

import android.app.SearchManager;
import android.content.Intent;
import android.graphics.Canvas;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.ItemTouchHelper;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
        private RecyclerView recyclerView;
        MyAdapter adapter;
        ArrayAdapter<Cardfill> adapter1;
        private RecyclerView.LayoutManager layoutManager;
        List<Cardfill> messagelist;
        SwipeController swipeController = null;
        SearchView searchView;
        Intent i;
        String publicKey = "";
        String privateKey = "";
        String secretkey = "";
        public static String num;
        DatabaseReference ref1;
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            i = getIntent();
            num = i.getStringExtra("number");
            checkdatabase();
            recyclerView = findViewById(R.id.my_recycler_view);
            layoutManager = new LinearLayoutManager(this);
            recyclerView.setLayoutManager(layoutManager);
            ref1= FirebaseDatabase.getInstance().getReference(num).child("sms");
            messagelist = new ArrayList<>();
            loadmessages();
            adapter1 = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, messagelist);
            swipeController = new SwipeController(new SwipeControllerActions() {
                @Override
                public void onRightClicked(int position) {
                    Toast.makeText(MainActivity.this, adapter.getContact(position), Toast.LENGTH_SHORT).show();
                    ref1.removeValue();
                    adapter.removeItem(position);
                    loadmessages();
                }
            });

            ItemTouchHelper itemTouchhelper = new ItemTouchHelper(swipeController);
            itemTouchhelper.attachToRecyclerView(recyclerView);

            recyclerView.addItemDecoration(new RecyclerView.ItemDecoration() {
                @Override
                public void onDraw(Canvas c, RecyclerView parent, RecyclerView.State state) {
                    swipeController.onDraw(c);
                }
            });
        }

        private void loadmessages() {

            ref1.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    try {
                        for (DataSnapshot postsnapShot : dataSnapshot.getChildren()) {
                            StoringData map = postsnapShot.getValue(StoringData.class);
                            messagelist.add(new Cardfill(R.drawable.ic_person_black_24dp, map.getSendernumber(), map.getMessage_entered(),map.getID()));
                        }
                    } catch (NullPointerException e) {
                        Toast.makeText(MainActivity.this, "" + e, Toast.LENGTH_SHORT).show();
                    }
                    adapter = new MyAdapter(getApplicationContext(), messagelist);
                    recyclerView.setAdapter(adapter);
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {
                    System.out.println("The read failed: " + databaseError.getCode());
                }
            });

        }

        private void checkdatabase() {
            final DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
            ref.child(num).addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                    } else {
                        try {
                            Map<String, Object> keyMap = Rsa.initKey();
                            publicKey = Rsa.getPublicKey(keyMap);
                            privateKey = Rsa.getPrivateKey(keyMap);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        String id=ref.child(num).push().getKey();
                        StoringData storingData = new StoringData(id,num, "6301279566", "welcome to SMS Encryption", "AES","");
                        ref.child(num).child("sms").child(id).setValue(storingData);
                        ref.child(num).child("privatekey").setValue(privateKey);
                        ref.child(num).child("publickey").setValue(publicKey);
                        ref.child(num).child("secretkey").setValue(secretkey);
                        Intent i = new Intent(MainActivity.this, Question.class);
                        i.putExtra("number", num);
                        startActivity(i);
                    }
                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }
            });
        }
        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            MenuInflater inflater = getMenuInflater();
            inflater.inflate(R.menu.searchcreate, menu);
            SearchManager searchManager = (SearchManager) getSystemService(getApplicationContext().SEARCH_SERVICE);
            searchView = (SearchView) menu.findItem(R.id.search).getActionView();
            searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
            searchView.setMaxWidth(Integer.MAX_VALUE);
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String query) {
                    adapter.getFilter().filter(query);
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String query) {
                    // filter recycler view when text is changed
                    adapter.getFilter().filter(query);
                    return false;
                }
            });
            return true;
        }
        @Override
        public boolean onOptionsItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case R.id.new_message:
                    Intent i = new Intent(getApplicationContext(), PageFragement.class);
                    i.putExtra("sendnumber", num);
                    startActivity(i);
                    return true;
                case R.id.search:
                    return true;
                case R.id.notify:
                    Intent i1 = new Intent(MainActivity.this, Notification_try.class);
                    startActivity(i1);
                    return true;

                default:
                    return super.onOptionsItemSelected(item);
            }

        }
        private void search(MenuItem item) {
            SearchView searchView = (SearchView) item.getActionView();
            searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                @Override
                public boolean onQueryTextSubmit(String s) {
                    return false;
                }

                @Override
                public boolean onQueryTextChange(String s) {
                    adapter1.getFilter().filter(s);
                    return false;
                }
            });
        }
        public static String getNum() {
            return num;
        }
    }
